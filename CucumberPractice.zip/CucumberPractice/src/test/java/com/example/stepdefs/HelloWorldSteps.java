// src/test/java/com/example/stepdefs/HelloWorldSteps.java
package com.example.stepdefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class HelloWorldSteps {

    @Given("I have a working Cucumber-Java setup")
    public void i_have_a_working_cucumber_java_setup() {
        // Setup code
    }

    @When("I run the test")
    public void i_run_the_test() {
        // Test run code
    }

    @Then("I should see {string} in the console")
    public void i_should_see_in_the_console(String expectedMessage) {
        System.out.println(expectedMessage);
    }
}
